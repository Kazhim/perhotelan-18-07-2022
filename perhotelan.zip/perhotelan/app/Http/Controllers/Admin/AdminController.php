<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\tamu;

class AdminController extends Controller
{
    public function index()
    {
      $users = tamu::where('id', '!=',0)->count();
        return view('fronhend.dashbord', compact('users'));
    }
  
}

