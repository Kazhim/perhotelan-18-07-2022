<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\booking;

class BookingController extends Controller
{
    public function tampilanBooking()
  {
    return view('fronhend.booking');
  }

  public function tampilandatabooking()
  {
    $data = [];
    $booking = Booking::get();
    foreach ($booking as $item) {
      $data[] = [
          $item->id,
          $item->tamu_id,
          $item->kamar_id,
          $item->fasilitas_id,
          $item->tanggal_booking,
          '<a href="/edit/'.$item->id.'" class="btn btn-primary">Edit</a>, <a href="/delete/'.$item->id.'" class="btn btn-danger">Delete</a>'
      
      ];
  }

    return [
      'data' => $data,
    ];
  }
}
