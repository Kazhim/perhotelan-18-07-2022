<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\fasilitas;

class FasilitasController extends Controller
{
  public function fasilitas()
  {
    return view('fronhend.fasilitas');
  }
  public function create()
  {
      return view('fronhend.from-inputfasilitas');
  }
  public function storefasilitas(Request $request)
  {
     $status = fasilitas::storefasilitas($request);
     if ($status)return redirect('/fasilitas');
     else return redirect('/from-inputfasilitas');
 
     }
     public function datatablefasilitas()
     {
       $data = [];
       $fasilitas = Fasilitas::get();
       foreach ($fasilitas as $item) {
         $data[] = [
             $item->id,
             $item->nama_fasilitas,
             $item->harga,
             '<a href="/edit/'.$item->id.'" class="btn btn-primary">Edit</a>, <a href="/delete/'.$item->id.'" class="btn btn-danger">Delete</a>'
         
         ];
     }
 
       return [
         'data' => $data,
       ];
      }
}
