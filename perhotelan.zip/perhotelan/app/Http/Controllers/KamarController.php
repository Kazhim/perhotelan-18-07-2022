<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\kamar;

class KamarController extends Controller
{
    public function Kamar()
    {
      return view('fronhend.kamar');
    }
    public function create()
    {
        return view('fronhend.from-inputkamar');
    }
    public function storekamar(Request $request)
    {
       $status = kamar::storekamar($request);
       if ($status)return redirect('/kamar');
       else return redirect('/from-inputkamar');
   
       }
       public function datatablekamar()
       {
         $data = [];
         $kamar = Kamar::get();
         foreach ($kamar as $item) {
           $data[] = [
               $item->id,
               $item->nama_kamar,
               '<a href="/edit/'.$item->id.'" class="btn btn-primary">Edit</a>, <a href="/delete/'.$item->id.'" class="btn btn-danger">Delete</a>'
           
           ];
       }
   
         return [
           'data' => $data,
         ];
        }
      }