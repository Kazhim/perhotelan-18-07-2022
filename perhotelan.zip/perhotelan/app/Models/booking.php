<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class booking extends Model
{
    use HasFactory;
    protected $fillable = [
        'tamu_id',
        'kamar_id',
        'fasilitas_id',
        'tanggal_booking',
    ];

    public function scopeStoreBooking($query, $request)
    {
        $status = $query->create([
            'tamu_id' => $request->tamu_id,
            'kamar_id' => $request->kamar_id,
            'fasilitas_id' => $request->fasilitas_id,
            'tanggal_booking' => $request->tanggal_booking,
           

        ]);

        if(!$status) return false;

        return true;
    }

    public function scopeUpdateBooking($query, $request)
    {
        $status = $query->where('id', $request->id)->update([
            'tamu_id' => $request->tamu_id,
            'kamar_id' => $request->kamar_id,
            'fasilitas_id' => $request->fasilitas_id,
            'tanggal_booking' => $request->tanggal_booking,
           
        ]);

        if(!$status) return false;

        return true;
    }
}
