<?php

namespace App\Models;

use Facade\Ignition\QureyRecorder\Query;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class kamar extends Model
{
    use HasFactory;

   
    protected $fillable = [
        'nama_kamar',
    ];

    public function scopeStoreKamar($query, $request)
    {
        $status = $query->create([
            'nama_kamar'  => $request->nama_kamar,
            


        ]);

        if(!$status) return false;

        return true;
    }

    public function scopeUpdateKamar($query, $request)
    {
        $status = $query->where('id', $request->id)->update([
            'nama_kamar'  => $request->nama_kamar,
           
        ]);

        if(!$status) return false;

        return true;
    }
}
