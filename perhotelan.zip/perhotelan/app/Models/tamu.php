<?php

namespace App\Models;

use Facade\Ignition\QureyRecorder\Query;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tamu extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama_tamu',
        'nama_alamat',
        'no_telpon',
    
    ];

    public function scopeStoreTamu($query, $request)
    {
        $status = $query->create([
            'nama_tamu' => $request->nama_tamu,
            'nama_alamat' => $request->nama_alamat,
            'no_telpon' => $request->no_telpon,
            


        ]);

        if(!$status) return false;

        return true;
    }

    public function scopeUpdateTamu($query, $request)
    {
        $status = $query->where('id', $request->id)->update([
            'nama_tamu' => $request->nama_tamu,
            'nama_alamat' => $request->nama_alamat,
            'no_telpon' => $request->no_telpon,
           
        ]);

        if(!$status) return false;

        return true;
    }
    public function scopeUpdatePesanan($query, $request)
    {
        $status = $query->where('id', $request->id)->update([
            'nama_tamu' => $request->nama_tamu,
            'nama_alamat' => $request->nama_alamat,
            'no_telpon' => $request->no_telpon,
            
        ]);

        if(!$status) return false;

        return true;
    }

}


