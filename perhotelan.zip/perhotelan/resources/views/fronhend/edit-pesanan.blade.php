@extends('layout.admin')

@section('content')
  <div class="card">
    <div class="card-body">
      <form method="POST" action="update">
        @csrf
        <div class="card">
    <div class="card-body">
      <form method="POST" action="/store-tamu">
        @csrf
        <div class="mb-3">
          <label type="hidden" for="exampleInputEmail1">Nama Tamu</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama_tamu" placeholder="masukan Nama " aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">Nama Kamar</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama_kamar" placeholder="masukan Kamar" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">No Telpon</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="no_telpon" placeholder="masukan nomor" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">Fasilitas</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="fasilitas" placeholder="masukan fasilitas" aria-describedby="emailHelp">
        </div>
        <button type="submit" class="btn btn-primary float-end">Update</button>
      </form>
    </div>
  </div>
@endsection