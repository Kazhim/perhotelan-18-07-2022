@extends('layout.admin')

@section('content')
        <div class="card">
    <div class="card-body">
      <form method="POST" action="/update">
        @csrf
        <div class="mb-3">
        <input type="hidden" name="id" value="{{ $tamus->id }}">
          <label for="exampleInputEmail1">Nama Tamu</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama_tamu" placeholder="No Kamar" aria-describedby="emailHelp" value="{{$tamus->nama_tamu}}">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">Alamat</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama_alamat" placeholder="No Kamar" aria-describedby="emailHelp" value="{{$tamus->nama_alamat}}">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">No Telpon</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="no_telpon" placeholder="No Kamar" aria-describedby="emailHelp"value="{{$tamus->no_telpon}}">
        </div> 
        <button type="submit" class="btn btn-primary float-end">Update</button>
      </form>
    </div>
  </div>
@endsection