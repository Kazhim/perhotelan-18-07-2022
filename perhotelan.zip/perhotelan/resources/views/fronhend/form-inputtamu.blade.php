@extends('layout.admin')

@section('content')
  <div class="card">
    <div class="card-body">
      <form method="POST" action="/store-tamu">
        @csrf
        <div class="mb-3">
          <label for="exampleInputEmail1">Nama Tamu</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama_tamu" placeholder="Masukan Nama Kamar" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">Alamat</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama_alamat" placeholder="Masukan Nama Alamat" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">No Telpon</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="no_telpon" placeholder="Masukan Nomor Telpon" aria-describedby="emailHelp">
        </div> 
        <button type="submit" class="btn btn-primary float-end">Tambah</button>
      </form>
    </div>
  </div>
@endsection