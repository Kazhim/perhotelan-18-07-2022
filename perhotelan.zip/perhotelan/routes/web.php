<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
  return view('welcome');
});

Route::get('/dashbord',[App\Http\Controllers\Admin\AdminController::class,'index']);
//tamu
Route::get('tamu',[App\Http\Controllers\TamuController::class,'tamu']);
Route::get('/form-inputtamu',[App\Http\Controllers\TamuController::class,'create']);
Route::post('/store-tamu',[App\Http\Controllers\TamuController::class,'storetamu']);
Route::get('/datatable/tamu',[App\Http\Controllers\TamuController::class,'datatabletamu']);
Route::get('/delete/{id}', [App\Http\Controllers\TamuController::class, 'destroy']);
Route::get('/edit/{id}', [App\Http\Controllers\TamuController::class, 'edit']);
Route::post('/update', [App\Http\Controllers\TamuController::class, 'update']);
//kamar
Route::get('kamar',[App\Http\Controllers\KamarController::class,'kamar']);
Route::get('/from-inputkamar',[App\Http\Controllers\KamarController::class,'create']);
Route::post('/store-kamar',[App\Http\Controllers\KamarController::class,'storekamar']);
Route::get('/datatable/kamar',[App\Http\Controllers\KamarController::class,'datatablekamar']);
//fasilitas
Route::get('fasilitas',[App\Http\Controllers\FasilitasController::class,'fasilitas']);
Route::get('/from-inputfasilitas',[App\Http\Controllers\FasilitasController::class,'create']);
Route::post('/store-fasilitas',[App\Http\Controllers\FasilitasController::class,'storefasilitas']);
Route::get('/datatable/fasilitas',[App\Http\Controllers\FasilitasController::class,'datatablefasilitas']);
//booking
Route::get('/databooking/booking', [App\Http\Controllers\BookingController::class, 'tampilandatabooking']);
Route::get('/booking', [App\Http\Controllers\BookingController::class, 'tampilanBooking']);
//pesan
Route::get('/', [App\Http\Controllers\PesanController::class, 'pesan']);
Route::post('/order-sukses',[App\Http\Controllers\PesanController::class, 'storepesan']);
Route::post('/order-sukses',[App\Http\Controllers\PesanController::class, 'sukses']);


   
