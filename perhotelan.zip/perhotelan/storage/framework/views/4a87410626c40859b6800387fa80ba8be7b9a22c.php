<nav id="sidebar" class="sidebar js-sidebar">
  <div class="sidebar-content js-simplebar">
    <a class="sidebar-brand" href="/dashbord">
      <span class="align-middle"><marquee>HOTEL KAZHIM HAKIIM</marquee></span>
    </a>

    <ul class="sidebar-nav">
      <li class="sidebar-header">
        Main Menu
      </li>

      <li class="sidebar-item <?php echo e(str_contains(request()->path(), 'dashbord') ? 'active' : null); ?>">
        <a class="sidebar-link" href="/dashbord">
          <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
        </a>
      </li>

      <li class="sidebar-item <?php echo e(str_contains(request()->path(), 'tamu') ? 'active' : null); ?>">
        <a class="sidebar-link" href="/tamu">
          <i class="align-middle" data-feather="user"></i> <span class="align-middle">Tamu</span>
        </a>
      </li>

      <li class="sidebar-item <?php echo e(str_contains(request()->path(), 'kamar') ? 'active' : null); ?>">
						<a class="sidebar-link" href="/kamar">
              <i class="align-middle" data-feather="home"></i> <span class="align-middle">Kamar </span>
            </a>
					</li>

      <li class="sidebar-item <?php echo e(str_contains(request()->path(), 'fasilitas') ? 'active' : null); ?>">
        <a class="sidebar-link" href="/fasilitas">
          <i class="align-middle" data-feather="clipboard"></i> <span class="align-middle">Fasilitas</span>
        </a>
      </li>

      <li class="sidebar-item <?php echo e(str_contains(request()->path(), 'booking') ? 'active' : null); ?>">
        <a class="sidebar-link" href="/booking">
          <i class="align-middle" data-feather="message-square"></i> <span class="align-middle">Booking</span>
        </a>
      </li>
  </div>
</nav><?php /**PATH C:\laragon\www\perhotelan\resources\views/components/sidebar.blade.php ENDPATH**/ ?>