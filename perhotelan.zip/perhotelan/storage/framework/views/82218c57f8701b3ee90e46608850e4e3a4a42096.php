

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">

<div class="card">
    <div calss="card-header">
        Data Kamar
</div>
<div class="card-body">
<table class="table datatable" id="tamu">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">No Kamar</th>
            <th scope="col">Nama Kamar</th>
            <th scope="col">Is Booked</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
        </tbody>
      </table>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
  
  <script>
    $('#tamu').DataTable({
      'ajax': '/datatamu/tamu'
    })
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perhotelan\resources\views/fronhend/datatamu.blade.php ENDPATH**/ ?>